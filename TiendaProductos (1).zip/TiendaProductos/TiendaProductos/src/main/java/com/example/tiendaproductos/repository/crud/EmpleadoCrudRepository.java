package com.example.tiendaproductos.repository.crud;

import com.example.tiendaproductos.entity.Empleado;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Optional;

public interface EmpleadoCrudRepository extends CrudRepository<Empleado,Integer> {
    Optional<Empleado> findByCorreo (String correo);
    UserDetails findByEmail(String correo);
}
