package com.example.tiendaproductos.service;


import com.example.tiendaproductos.entity.Usuario;
import com.example.tiendaproductos.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DaoSupport;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("userDetailsService")
public class UsuarioService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private DaoSupport userDao;

    public Usuario save(Usuario u) {return usuarioRepository.save(u);}
    public Optional<Usuario> findByCorreo(String correo) {return usuarioRepository.findByCorreo(correo);}


    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return usuarioRepository.findByUsername(username);
    }
}
