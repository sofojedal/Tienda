package com.api.gestion.restController;


import org.springframework.stereotype.Controller;

@Controller
public class QRCodeController {
}
