package com.api.gestion.daoRepository;

import com.api.gestion.pojoEntity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDAO extends JpaRepository<User, Integer> {


    User findByEmail(@Param(("email")) String email);
}
