package com.example.tiendaproductos.controller;

import com.example.tiendaproductos.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register-user")
    public ResponseEntity<AuthenticationResponse> registerUsuario(@RequestBody RegisterRequest request){
        return ResponseEntity.ok(authService.registerUser(request));
    }

    @PostMapping("/authenticate-user")
    public ResponseEntity<AuthenticationResponse> authUsuario(@RequestBody AuthenticationRequest request){
        return ResponseEntity.ok(authService.authenticateUser(request));
    }


    @PostMapping("/register-emp")
    public ResponseEntity<AuthenticationResponse> registerEmp(@RequestBody RegisterRequest request){
        return ResponseEntity.ok(authService.registerEmp(request));
    }

    @PostMapping("/authenticate-emp")
    public ResponseEntity<AuthenticationResponse> authEmp(@RequestBody AuthenticationRequest request){
        return ResponseEntity.ok(authService.authenticateEmp(request));
    }

}
