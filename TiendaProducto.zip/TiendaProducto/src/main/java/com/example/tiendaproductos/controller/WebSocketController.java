package com.example.tiendaproductos.controller;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class WebSocketController {
    @MessageMapping("/generateWebSocketQR")
    @SendTo("/topic/qrCode")
    public String generateQRCode(String qrData){
        String response = "Código QR procesado: " + qrData;
        return response;
    }
}
