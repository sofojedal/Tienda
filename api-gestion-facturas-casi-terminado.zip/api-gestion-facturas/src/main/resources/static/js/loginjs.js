const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

mongoose.connect('mongodb://localhost/login_app', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
    console.log('Connected to DB');
});

const userSchema = new mongoose.Schema({
    username: String,
    password: String
});

const User = mongoose.model('User', userSchema);

app.post('/signup', (req, res) => {
    const user = new User(req.body);

    user.save((err) => {
        if (err) return res.status(500).send(err);
        res.status(200).send('User created');
    });
});

app.post('/signin', (req, res) => {
    User.findOne({ username: req.body.username }, (err, user) => {
        if (err) return res.status(500).send(err);
        if (!user) return res.status(403).send('User not found');

        user.isCorrectPassword(req.body.password, (err, same) => {
            if (err) return res.status(500).send(err);
            if (!same) return res.status(403).send('Wrong password');

            res.status(200).send('Successfully signed in');
        });
    });
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
