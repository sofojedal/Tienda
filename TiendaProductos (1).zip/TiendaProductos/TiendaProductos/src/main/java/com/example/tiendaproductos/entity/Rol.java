package com.example.tiendaproductos.entity;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor

public enum Rol {

    EMPLEADO,
    USUARIO
}
