document.addEventListener("DOMContentLoaded", function () {
    const qrForm = document.getElementById("qrForm");
    const qrVideo = document.getElementById("qrVideo");
    const qrCanvas = document.getElementById("qrCanvas");
    const scanButton = document.getElementById("scanButton");
    const qrCodeDisplay = document.getElementById("qrCodeDisplay");
    const qrImage = document.getElementById("qrImage");

    let scanner;
    let stompClient;

    // Configuración para la conexión WebSocket
    const socket = new SockJS("/ws");
    stompClient = Stomp.over(socket);



    // Configuración para el escaneo de código QR
    scanner = new Instascan.Scanner({ video: qrVideo });
    scanner.addListener("scan", function (content) {
        // Cuando se escanea el código QR, enviarlo al servidor
        stompClient.send("/app/generateQR", {}, content);



        // Mostrar el código QR escaneado
        qrCodeDisplay.style.display = "block";
        qrImage.src = `data:image/png;base64, ${content}`;
    });



    // Manejar el evento de clic en el botón "Escanear"
    scanButton.addEventListener("click", function (e) {
        e.preventDefault();
        qrCodeDisplay.style.display = "none";
        scanner.start(qrVideo);
    });



    // Conectar al servidor WebSocket
    stompClient.connect({}, function (frame) {
        console.log("Conexión WebSocket establecida.");
    });


    // Manejar la respuesta del servidor a través del canal WebSocket
    stompClient.subscribe("/topic/qrCodeResponse", function (response) {
        const qrResponse = response.body;
        // Mostrar la respuesta o autenticar al usuario
        console.log("Respuesta del servidor:", qrResponse);
    });
});
