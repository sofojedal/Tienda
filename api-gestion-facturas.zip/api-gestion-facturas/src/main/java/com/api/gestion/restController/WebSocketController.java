package com.api.gestion.restController;


import com.api.gestion.service.UserService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class WebSocketController {

    // Inyecta el servicio UserService para verificar el token
    private final UserService userService;

    public WebSocketController(UserService userService) {
        this.userService = userService;
    }

    @MessageMapping("/authenticateQR")
    @SendTo("/topic/qrCodeResponse")
    public String authenticateQRCode(String qrData) {
        // Verificar el token en el servidor
        boolean isValidToken = userService.authenticateQRCode(qrData);
        if (isValidToken) {
            return "Código QR autenticado con éxito";
        } else {
            return "Error en la autenticación del código QR";
        }
    }

}
