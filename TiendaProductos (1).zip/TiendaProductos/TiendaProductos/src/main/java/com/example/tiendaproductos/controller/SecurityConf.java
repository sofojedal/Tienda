package com.example.tiendaproductos.controller;

import jakarta.servlet.Filter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConf {

    private final JwtAuthFilter jwtAuthFilter;
    private final AuthenticationProvider authenticationProvider;
    @SuppressWarnings("removal")
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        //Seccion para elegir qué partes del proyecto estarán protegidas y cuales no.
        //Tambien puedo configurar Todooo lo relacionado a security
        http
                .csrf()
                .disable()
                .authorizeHttpRequests()
                //Aquí en forma de strings van las paginas que se permiten
                .requestMatchers("/api/auth/**") //** implica que van TODAS las url hijas. Se puede añadir una por una.
                .permitAll()
                .anyRequest() //Cualquier petición
                .authenticated() //Deberá ser autenticada
                //Para añadir una nueva configuracion uso and()
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)//Stateless implica que por cada solicitud se crera una sesion
                //Otra configuracion
                .and()
                .authenticationProvider(authenticationProvider)
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }


}
