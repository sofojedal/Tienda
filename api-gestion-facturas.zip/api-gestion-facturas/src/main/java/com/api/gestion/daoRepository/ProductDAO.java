package com.api.gestion.daoRepository;


import com.api.gestion.pojoEntity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductDAO extends JpaRepository<Product, Integer> {

    Product findByNombre(@Param(("nombre"))String nombre);
}
