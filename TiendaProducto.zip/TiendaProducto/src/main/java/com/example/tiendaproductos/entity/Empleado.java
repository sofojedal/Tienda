package com.example.tiendaproductos.entity;

public class Empleado extends  Persona{

    public Empleado(Integer ID, String nombre, String apellido, String correo) {
        super(ID, nombre, apellido, correo);
    }


}
