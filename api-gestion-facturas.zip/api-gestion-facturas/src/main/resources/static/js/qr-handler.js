var qr = new QRCode(document.getElementById("qrcode"));
var scanner = new Instascan.Scanner({ video: document.getElementById('preview') });

// Agregar evento al botón de autenticación
document.getElementById("authenticateButton").addEventListener("click", function () {
    autenticarCodigoQR();
});
// Agregar evento al botón de generación de código QR
document.getElementById("generateButton").addEventListener("click", function () {
    generarCodigoQR();
});
// Agregar evento al input de archivo para cargar códigos QR
document.getElementById("qrFileInput").addEventListener("change", function (event) {
    cargarCodigoQRDesdeArchivo(event);
});



function generarCodigoQR() {
    // Obtener el token del usuario desde el campo de entrada
    var userToken = document.getElementById("userToken").value;

    // Validar que el campo no esté vacío
    if (userToken.trim() === "") {
        alert("Por favor, ingrese el token del usuario.");
        return;
    }

    // Limpiar el código QR existente
    qr.clear();

    // Generar el código QR con el token del usuario
    qr.makeCode(userToken);
}

function cargarCodigoQRDesdeArchivo(event) {
    var input = event.target;
    var file = input.files[0];

    if (file) {
        var reader = new FileReader();
        reader.onload = function (e) {
            var imageData = e.target.result;
            cargarCodigoQRDesdeImagen(imageData);
        };
        reader.readAsDataURL(file);
    }
}

function cargarCodigoQRDesdeImagen(imageData) {
    // Limpiar el código QR existente
    qr.clear();

    // Crear una nueva imagen
    var img = new Image();
    img.src = imageData;

    // Cuando la imagen se carga, generar el código QR
    img.onload = function () {
        qr.makeCode(img.src);
    };
}

// Función para autenticar el código QR
function autenticarCodigoQR() {
    // Obtener el contenido del código QR
    var userToken = document.getElementById("userToken").value;

    // Validar que el campo no esté vacío
    if (userToken.trim() === "") {
        alert("Por favor, ingrese el token del usuario.");
        return;
    }

    // Enviar el contenido del código QR al servidor para autenticación
    stompClient.send("/app/authenticateQR", {}, userToken);
}

// Configurar el escáner de código QR
scanner.addListener('scan', function (content) {
    // Enviar el contenido del código QR al servidor para la verificación
    enviarDatosAlServidor(content);
});

// Iniciar la cámara al cargar la página
Instascan.Camera.getCameras().then(function (cameras) {
    if (cameras.length > 0) {
        scanner.start(cameras[0]);
    } else {
        console.error('No se encontró una cámara.');
    }
});

// Resto del código (configuración de WebSockets, etc.)
var socket = new SockJS('/ws');
var stompClient = Stomp.over(socket);

// Conectar al servidor WebSocket
stompClient.connect({}, function (frame) {
    console.log('Conectado al servidor WebSocket:', frame);

    // Suscribirse al tema donde el servidor enviará las respuestas de autenticación del código QR
    stompClient.subscribe('/topic/qrCodeResponse', function (response) {
        // Manejar la respuesta del servidor
        console.log('Respuesta del servidor:', response.body);
        alert(response.body); // Puedes mostrar la respuesta en un modal, alerta, etc.
    });
});
