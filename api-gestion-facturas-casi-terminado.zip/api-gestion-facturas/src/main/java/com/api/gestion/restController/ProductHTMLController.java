package com.api.gestion.restController;

import com.api.gestion.pojoEntity.Product;
import com.api.gestion.service.ProductService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class ProductHTMLController {

    @Autowired
    private ProductService productService;

    private List<Product> carrito = new ArrayList<>();

    @GetMapping("/productList")
    public String showProductList(Model model) {
        try {

            List<Product> productList = productService.getAllProducts();
            model.addAttribute("productos", productList);


            return "productList";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/product/{id}")
    public String showProduct(@PathVariable Integer id, Model model) {
        try {
            Product product = productService.getProductById(id);

            // Agrega el producto al modelo
            model.addAttribute("producto", product);
            return "productDetail";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/facturacion")
    public String mostrarFacturacion(Model model, HttpSession session) {
        // Obtener el carrito de la sesión
        List<Product> carrito = (List<Product>) session.getAttribute("carrito");

        if (carrito == null) {
            // Si el carrito no existe en la sesión, crea uno nuevo
            carrito = new ArrayList<>();
            session.setAttribute("carrito", carrito);
        }

        model.addAttribute("carrito", carrito);
        return "facturacion";
    }

    @PostMapping("/agregarAlCarrito")
    public String agregarAlCarrito(@ModelAttribute Product product, Model model, HttpSession session) {
        // Obtener el carrito de la sesión
        List<Product> carrito = (List<Product>) session.getAttribute("carrito");

        if (carrito == null) {
            // Si el carrito no existe en la sesión, crea uno nuevo
            carrito = new ArrayList<>();
            session.setAttribute("carrito", carrito);
        }

        // Lógica para agregar el producto al carrito
        carrito.add(product);

        // Agrega la lista de productos al modelo
        model.addAttribute("carrito", carrito);

        // Redirige a la página de facturación
        return "redirect:/facturacion";
    }




    @GetMapping("/registrarProducto")
    public String showProductForm() {
        return "registrarProducto";
    }



    @PostMapping("/registrarProducto")
    public ResponseEntity<Object> registerProduct(@RequestBody Map<String, String> productData) {
        try {
            // Llama al servicio para crear un nuevo producto
            Product newProduct = productService.createProduct(productData);

            if (newProduct != null) {
                // Devuelve una respuesta exitosa con el nuevo producto creado
                return new ResponseEntity<>(newProduct, HttpStatus.CREATED);
            } else {
                // Devuelve una respuesta de conflicto si el producto ya existe
                return new ResponseEntity<>("El producto ya existe o faltan datos requeridos", HttpStatus.CONFLICT);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Devuelve una respuesta de error en caso de excepción
            return new ResponseEntity<>("Error al procesar la solicitud", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    @GetMapping("/buscarProducto")
    public String buscarProducto() {
        return "buscarProducto";
    }




    @PostMapping("/buscarProducto")
    public String buscarProducto(@RequestParam("nombre") String nombre, Model model) {
        try {
            // Lógica para buscar el producto por nombre
            Product product = productService.getProductByNombre(nombre);

            if (product != null) {
                // Si el producto existe, agrega el nombre al modelo y redirige a la página de actualizarProducto
                model.addAttribute("nombreProducto", nombre);
                return "redirect:/actualizarProducto";
            } else {
                // Si el producto no existe, muestra un mensaje de alerta
                model.addAttribute("alerta", "No se encontró el producto");
                return "buscarProducto";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/actualizarProducto")
    public String actualizarProducto() {
        return "actualizarProducto";
    }

    @GetMapping("/actualizarProducto/{nombre}")
    public String actualizarProducto(@PathVariable String nombre, Model model) {
        try {
            // Obtener el producto por nombre
            Product product = productService.getProductByNombre(nombre);

            if (product != null) {
                // Agregar el producto al modelo
                model.addAttribute("producto", product);
                return "actualizarProducto";
            } else {
                // Si el producto no existe, mostrar un mensaje de error
                model.addAttribute("error", "No se encontró el producto");
                return "buscarProducto";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }



    @PutMapping("/actualizarProducto/{nombre}")
    public ResponseEntity<String> updateProduct(@PathVariable String nombre, @RequestBody Map<String, String> requestMap) {
        Product updatedProduct = productService.updateProductByName(nombre, requestMap);

        if (updatedProduct != null) {
            return ResponseEntity.ok("Producto actualizado correctamente");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el producto para actualizar");
        }
    }


    @GetMapping("/eliminarProducto")
    public String eliminarProducto() {
        return "eliminarProducto";
    }

    @DeleteMapping("/eliminarProducto/{nombre}")
    public ResponseEntity<String> eliminarProducto(@PathVariable String nombre) {
        try {
            // Lógica para eliminar el producto por nombre
            productService.deleteProductByName(nombre);

            return new ResponseEntity<>("Producto eliminado correctamente", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("Error al eliminar el producto", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
