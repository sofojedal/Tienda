package com.api.gestion.restController;

import com.api.gestion.constantes.FacturaConstantes;
import com.api.gestion.pojoEntity.Product;
import com.api.gestion.pojoEntity.User;
import com.api.gestion.service.ProductService;
import com.api.gestion.service.UserService;
import com.api.gestion.util.FacturaUtils;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



import java.util.List;
import java.util.Map;

@Controller
public class LoginController {
    private static final Logger log = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    private UserService userService;



    @GetMapping("/login")
    public String showLoginFrom(){
        return "login";
    }

    @PostMapping("/login")
    public ResponseEntity<String> ingresar(@RequestBody Map<String, String> loginData) {
        try {
            // Llama al servicio para verificar el inicio de sesión
            ResponseEntity<String> response = userService.login(loginData);

            // Verificar si el inicio de sesión fue exitoso
            if (response.getStatusCode() == HttpStatus.OK) {
                // Devuelve un JSON con el mensaje de éxito
                return new ResponseEntity<>("{\"message\":\"Inicio de sesión exitoso\", \"redirect\":\"/productList\"}", HttpStatus.OK);
            } else {
                // Devuelve un JSON con el mensaje de error
                return new ResponseEntity<>("{\"error\":\"" + response.getBody() + "\"}", HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>("{\"error\":\"Error al procesar la solicitud\"}", HttpStatus.INTERNAL_SERVER_ERROR);
    }



    @GetMapping("/admin")
    public String showAdminFrom(){
        return "admin";
    }




    @GetMapping("/signup")
    public String showSignupFrom(){
        return "signup";
    }

    @PostMapping("/signup")
    public ResponseEntity<String> registrarUsuario(@RequestBody User user) {
        try {

            user.setRole("user");
            user.setStatus(String.valueOf(true));
            // Llama al servicio para registrar un nuevo usuario
            ResponseEntity<String> response = userService.registrarUsuario(user);

            // Verificar si el registro fue exitoso
            if (response.getStatusCode() == HttpStatus.CREATED) {
                // Devuelve un JSON con el mensaje de éxito y redirección
                return new ResponseEntity<>("{\"message\":\"Registro exitoso\", \"redirect\":\"/login\"}", HttpStatus.CREATED);
            } else {
                // Devuelve un JSON con el mensaje de error
                return new ResponseEntity<>("{\"error\":\"" + response.getBody() + "\"}", HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return FacturaUtils.getResponseEntity(FacturaConstantes.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @GetMapping("/usuario")
    public String showUserInfo(Model model, HttpSession session) {
        log.info("Ingresó a /usuario");

        User user = (User) session.getAttribute("user");

        // Verifica si el usuario está autenticado
        if (user != null) {
            // Agrega el usuario al modelo para mostrar la información en la página Usuario.html
            model.addAttribute("user", user);
            log.info("Usuario autenticado: {}", user.getEmail());
            return "usuario";
        } else {
            // Si el usuario no está autenticado, redirige al formulario de login
            log.warn("Intento de acceder a /usuario sin autenticación. Redirigiendo a /login");
            return "redirect:/login";
        }
    }
}
