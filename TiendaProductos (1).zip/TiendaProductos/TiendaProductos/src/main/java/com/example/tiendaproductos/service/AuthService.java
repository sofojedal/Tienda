package com.example.tiendaproductos.service;

import com.example.tiendaproductos.controller.AuthenticationRequest;
import com.example.tiendaproductos.controller.AuthenticationResponse;
import com.example.tiendaproductos.controller.RegisterRequest;
import com.example.tiendaproductos.entity.Empleado;
import com.example.tiendaproductos.entity.Usuario;
import com.example.tiendaproductos.repository.EmpleadoRepository;
import com.example.tiendaproductos.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.management.relation.Role;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UsuarioRepository usuarioRepository;

    private final EmpleadoRepository empleadoRepository;

    private final PasswordEncoder passwordEncoder;

    private final JwtService jwtService;

    private final AuthenticationManager authenticationManager;
    public AuthenticationResponse registerUser(RegisterRequest request) {
        var user = Usuario.builder()
                .nombre(request.getNombre())
                .apellido(request.getApellido())
                .correo(request.getCorreo())
                .pass(passwordEncoder.encode(request.getPass()))
                .build();

        usuarioRepository.save((Usuario) user);

        var jwtToken = jwtService.generateToken(user);

        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

    public AuthenticationResponse authenticateUser(AuthenticationRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getCorreo(),
                        request.getPass()
                )
        );

        var user = usuarioRepository.findByCorreo(request.getCorreo()).orElseThrow();
        var jwtToken = jwtService.generateToken(user);

        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

    public AuthenticationResponse registerEmp(RegisterRequest request) {
        var emp = Empleado.builder()
                .nombre(request.getNombre())
                .apellido(request.getApellido())
                .correo(request.getCorreo())
                .pass(passwordEncoder.encode(request.getPass()))
                .build();

        empleadoRepository.save((Empleado) emp);

        var jwtToken = jwtService.generateToken(emp);

        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

    public AuthenticationResponse authenticateEmp(AuthenticationRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getCorreo(),
                        request.getPass()
                )
        );

        var emp = empleadoRepository.findByCorreo(request.getCorreo()).orElseThrow();
        var jwtToken = jwtService.generateToken(emp);

        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }



}
