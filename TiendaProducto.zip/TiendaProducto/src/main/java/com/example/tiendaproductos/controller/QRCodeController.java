package com.example.tiendaproductos.controller;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Controller
public class QRCodeController {

    private Map<String, String> qrCodeTokens = new HashMap<>();

    @MessageMapping("/generateQRCode")
    @SendTo("/topic/qrCode")
    public String generateQRCode(String qrData){
        // Genera un token aleatorio para el usuario
        String token = generateRandomToken();
        // Asocia el token con los datos del código QR en un mapa
        qrCodeTokens.put(token, qrData);

        return token;
    }

    private String generateRandomToken(){
        return UUID.randomUUID().toString();
    }

    public boolean authenticateQRCode(String token, String qrData){
        if(qrCodeTokens.containsKey(token) && qrCodeTokens.get(token).equals(qrData)){
            return true;
        }
        return false;
    }
}
