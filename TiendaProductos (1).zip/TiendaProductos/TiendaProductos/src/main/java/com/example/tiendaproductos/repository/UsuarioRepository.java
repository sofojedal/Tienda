package com.example.tiendaproductos.repository;


import com.example.tiendaproductos.entity.Usuario;
import com.example.tiendaproductos.repository.crud.UsuarioCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class UsuarioRepository implements UserDetailsService {

    @Autowired
    private UsuarioCrudRepository usuarioCrudRepository;

    public Usuario save(Usuario u) {return  usuarioCrudRepository.save(u);}

    public Optional<Usuario> findByCorreo(String correo) {
        return usuarioCrudRepository.findByCorreo(correo);
    }

    public UserDetails findByUsername(String username){
        return usuarioCrudRepository.findByUsername(username);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return usuarioCrudRepository.findByUsername(username);
    }
    
}
