package com.api.gestion.service;

import com.api.gestion.pojoEntity.Product;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface ProductService {

    List<Product> getAllProducts();

    Product getProductById(Integer id);

    Product createProduct(Map<String, String> requestMap);

    Product updateProduct(Integer id, Map<String, String> requestMap);

    Product updateProductByName(String nombre, Map<String, String> requestMap);

    void deleteProduct(Integer id);

    void deleteProductByName(String nombre);

    Product getProductByNombre(String nombre);
}
