package com.api.gestion.restController;

import com.api.gestion.pojoEntity.Product;
import com.api.gestion.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/products")
@RequiredArgsConstructor
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Integer id) {
        return productService.getProductById(id);
    }

    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Map<String, String> requestMap) {
        Product createdProduct = productService.createProduct(requestMap);
        return createdProduct != null
                ? new ResponseEntity<>(createdProduct, HttpStatus.CREATED)
                : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Integer id, @RequestBody Map<String, String> requestMap) {
        Product updatedProduct = productService.updateProduct(id, requestMap);
        return updatedProduct != null
                ? new ResponseEntity<>(updatedProduct, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Integer id) {
        productService.deleteProduct(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/byNombre/{nombre}")
    public Product getProductByNombre(@PathVariable String nombre) {
        return productService.getProductByNombre(nombre);
    }

    @GetMapping("/products")
    public String showProductList(Model model) {
        List<Product> productList = productService.getAllProducts();
        model.addAttribute("productos", productList);
        return "productList";
    }


    @PostMapping("/register")
    public ResponseEntity<String> registerProduct(@RequestBody Map<String, String> requestMap) {
        try {
            // Validar que el mapa de solicitud contenga la información necesaria
            if (validateProductMap(requestMap)) {
                // Crear un nuevo producto a partir del mapa de solicitud
                Product newProduct = productService.createProduct(requestMap);

                // Verificar si la creación del producto fue exitosa
                if (newProduct != null) {
                    // Puedes redirigir o mostrar un mensaje según la respuesta
                    return new ResponseEntity<>("{\"message\":\"Producto registrado con éxito\"}", HttpStatus.CREATED);
                } else {
                    // Mostrar una alerta en caso de error
                    return new ResponseEntity<>("{\"error\":\"Error al registrar el producto\"}", HttpStatus.INTERNAL_SERVER_ERROR);
                }
            } else {
                // Mostrar una alerta si la solicitud es inválida
                return new ResponseEntity<>("{\"error\":\"Datos de producto inválidos\"}", HttpStatus.BAD_REQUEST);
            }
        } catch (NumberFormatException e) {
            // Manejar el error de conversión de número
            e.printStackTrace();
            return new ResponseEntity<>("{\"error\":\"Error de formato de número\"}", HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("{\"error\":\"Error interno del servidor\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Método de validación para verificar la presencia de datos necesarios y el formato correcto de los números
    private boolean validateProductMap(Map<String, String> requestMap) {
        return requestMap.containsKey("nombre") &&
                requestMap.containsKey("descripcion") &&
                requestMap.containsKey("precio") &&
                requestMap.containsKey("stock") &&
                isNumeric(requestMap.get("precio")) &&
                isNumeric(requestMap.get("stock"));
    }

    // Método auxiliar para verificar si una cadena es numérica
    private boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }



}
