package com.example.tiendaproductos.controller;

import lombok.Data;

@Data
public class AuthenticationRequest {

    private String correo;
    private String pass;

    public AuthenticationRequest(String correo, String pass) {
        this.correo = correo;
        this.pass = pass;
    }

    public AuthenticationRequest() {
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    @Override
    public String toString() {
        return "AuthenticationRequest{" +
                "correo='" + correo + '\'' +
                ", pass='" + pass + '\'' +
                '}';
    }

}
