package com.example.tiendaproductos.entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Builder
public class Empleado extends  Persona{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer ID;

    private String nombre;
    private String apellido;
    private String correo;
    private String pass;

    public Empleado(Integer ID, String nombre, String apellido, String correo) {
        super(ID, nombre, apellido, correo);
    }


}
