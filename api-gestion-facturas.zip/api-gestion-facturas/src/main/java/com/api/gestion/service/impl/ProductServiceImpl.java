package com.api.gestion.service.impl;

import com.api.gestion.daoRepository.ProductDAO;
import com.api.gestion.pojoEntity.Product;
import com.api.gestion.service.ProductService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductDAO productDAO;

    @Override
    public List<Product> getAllProducts() {
        return productDAO.findAll();
    }

    @Override
    public Product getProductById(Integer id) {
        return productDAO.findById(id).orElse(null);
    }

    @Override
    public Product createProduct(Map<String, String> requestMap) {
        try {
            Product product = new Product();
            product.setNombre(requestMap.get("nombre"));
            product.setDescripcion(requestMap.get("descripcion"));
            product.setPrecio(requestMap.get("precio"));
            product.setStock(Integer.parseInt(requestMap.get("stock")));
            return productDAO.save(product);
        } catch (Exception e) {
            log.error("Error al crear un producto: {}", e.getMessage());
            return null;
        }
    }

    @Override
    public Product updateProduct(Integer id, Map<String, String> requestMap) {
        try {
            Product existingProduct = productDAO.findById(id).orElse(null);

            if (existingProduct != null) {
                existingProduct.setNombre(requestMap.get("nombre"));
                existingProduct.setDescripcion(requestMap.get("descripcion"));
                existingProduct.setPrecio(requestMap.get("precio"));
                existingProduct.setStock(Integer.parseInt(requestMap.get("stock")));
                return productDAO.save(existingProduct);
            }
        } catch (Exception e) {
            log.error("Error al actualizar un producto: {}", e.getMessage());
        }
        return null;
    }

    @Override
    public void deleteProduct(Integer id) {
        productDAO.deleteById(id);
    }

    @Override
    public Product getProductByNombre(String nombre) {
        return productDAO.findByNombre(nombre);
    }
}
