package com.example.tiendaproductos.entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Builder;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;

@Data
@Builder

public class Usuario extends Persona implements UserDetails{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer ID;

    private String nombre;
    private String apellido;
    private String correo;
    private String pass;

    private Float saldo;

    public Usuario(Integer ID, String nombre, String apellido, String correo) {
        super(ID, nombre, apellido, correo);
        this.saldo = 0F;
    }

    public Usuario(){

    }

}
