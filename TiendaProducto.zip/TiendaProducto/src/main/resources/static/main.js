document.addEventListener("DOMContentLoaded", function () {
    // Obtener el elemento de entrada de texto y el div donde se mostrará el código QR
    var qrInput = document.getElementById("qrInput");
    var qrCodeDiv = document.getElementById("qrcode");

    // Crear un nuevo objeto QRCode
    var qrcode = new QRCode(qrCodeDiv, {
        width: 128,
        height: 128,
    });

    // Generar el código QR cuando se envía el formulario
    document.getElementById("qrForm").addEventListener("submit", function (event) {
        event.preventDefault();
        var qrData = qrInput.value;
        if (qrData) {
            qrcode.makeCode(qrData); // Generar el código QR en el div
            sendQRCodeToServer(qrData); // Enviar el código QR al servidor
        }
    });

    // Función para enviar el código QR al servidor a través de WebSocket
    function sendQRCodeToServer(qrData) {
        // Configurar la conexión WebSocket
        var socket = new SockJS("/ws");
        var stompClient = Stomp.over(socket);

        stompClient.connect({}, function (frame) {
            // Enviar el código QR al servidor
            stompClient.send("/app/generateQR", {}, qrData);
        });
    }
});
