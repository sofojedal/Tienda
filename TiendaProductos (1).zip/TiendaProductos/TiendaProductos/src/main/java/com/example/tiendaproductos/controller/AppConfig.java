package com.example.tiendaproductos.controller;

import com.example.tiendaproductos.entity.Usuario;
import com.example.tiendaproductos.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AppConfig {

    private final UsuarioRepository usuarioRepository;
    @Bean
    public UserDetailsService userDetailsService(){
        //Busqueda del usuario usando el repositorio. Si no se encuentra, se envia la excepcion no encontrado.
        return username -> usuarioRepository.findByCorreo(username)
                            .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    }


    //Creo el bean encargado de administrar la autenticacion
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    //Creo el Bean responsable de manejar el objeto asociado a userdetails.
    @Bean
    public AuthenticationProvider authenticationProvider(){
        //Instancia del Data Object necesario para buscar y manipular la data
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        //Cargo los datos de mi userdetailsservice
        authProvider.setUserDetailsService(userDetailsService());
        //Le especifico cuál es el algoritmo que se uso para codificar las contraseñas y datos
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }


}
