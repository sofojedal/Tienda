package com.api.gestion.service.impl;

import com.api.gestion.daoRepository.ProductDAO;
import com.api.gestion.pojoEntity.Product;
import com.api.gestion.service.ProductService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;


@Slf4j
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductDAO productDAO;

    @Override
    public List<Product> getAllProducts() {
        return productDAO.findAll();
    }

    @Override
    public Product getProductById(Integer id) {
        return productDAO.findById(id).orElse(null);
    }

  /*  @Override
    public Product createProduct(Map<String, String> productData) {
        if (validateProductData(productData)) {
            // Crea un nuevo objeto Producto a partir del mapa de datos
            Product newProduct = new Product();
            newProduct.setNombre(productData.get("nombre"));
            newProduct.setDescripcion(productData.get("descripcion"));
            newProduct.setPrecio(Double.parseDouble(productData.get("precio")));
            newProduct.setStock(Integer.parseInt(productData.get("stock")));

            // Guarda el nuevo producto en la base de datos
            return productDAO.save(newProduct);
        } else {
            return null; // Devuelve null si los datos del producto no son válidos
        }
    }




    // Método de validación para verificar la presencia y el formato correcto de los datos
    private boolean validateProductData(Map<String, String> productData) {
        return productData.containsKey("nombre") &&
                productData.containsKey("descripcion") &&
                productData.containsKey("precio") &&
                productData.containsKey("stock") &&
                isNumeric(productData.get("precio")) &&
                isNumeric(productData.get("stock"));
    }

    private boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

*/




    @Override
    public Product createProduct(Map<String, String> requestMap) {
        try {
            // Validar que los datos requeridos estén presentes en el mapa
            if (validateProductMap(requestMap)) {
                // Verificar si ya existe un producto con el mismo nombre
                String nombre = requestMap.get("nombre");
                Product existingProduct = getProductByNombre(nombre);

                if (Objects.isNull(existingProduct)) {
                    // Crear un nuevo producto
                    Product newProduct = getProductFromMap(requestMap);
                    newProduct.setImagen(requestMap.get("imagen")); // Incluye la URL de la imagen
                    return productDAO.save(newProduct);
                } else {
                    // Devolver un producto existente con el mismo nombre
                    return existingProduct;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null; // Puedes manejar el error de otra manera según tus necesidades
    }



    private boolean validateProductMap(Map<String, String> requestMap) {
        return requestMap.containsKey("nombre") &&
                requestMap.containsKey("descripcion") &&
                requestMap.containsKey("precio") &&
                requestMap.containsKey("stock");
    }

    private Product getProductFromMap(Map<String, String> requestMap) {
        Product product = new Product();
        product.setNombre(requestMap.get("nombre"));
        product.setDescripcion(requestMap.get("descripcion"));
        product.setPrecio(Double.parseDouble(requestMap.get("precio")));
        product.setStock(Integer.parseInt(requestMap.get("stock")));
        return product;
    }







    @Override
    public Product updateProduct(Integer id, Map<String, String> requestMap) {
        try {
            Product existingProduct = productDAO.findById(id).orElse(null);

            if (existingProduct != null) {
                existingProduct.setNombre(requestMap.get("nombre"));
                existingProduct.setDescripcion(requestMap.get("descripcion"));
                existingProduct.setPrecio(Double.parseDouble(requestMap.get("precio")));
                existingProduct.setStock(Integer.parseInt(requestMap.get("stock")));
                return productDAO.save(existingProduct);
            }
        } catch (Exception e) {
            log.error("Error al actualizar un producto: {}", e.getMessage());
        }
        return null;
    }

    @Override
    public Product updateProductByName(String nombre, Map<String, String> requestMap) {
        try {
            Product existingProduct = productDAO.findByNombre(nombre);

            if (existingProduct != null) {
                // Actualizar los campos del producto
                existingProduct.setDescripcion(requestMap.get("descripcion"));
                existingProduct.setPrecio(Double.parseDouble(requestMap.get("precio")));
                existingProduct.setStock(Integer.parseInt(requestMap.get("stock")));

                // Guardar el producto actualizado en la base de datos
                return productDAO.save(existingProduct);
            } else {
                log.error("No se encontró ningún producto con el nombre: {}", nombre);
            }
        } catch (NumberFormatException e) {
            log.error("Error al convertir tipos: {}", e.getMessage());
        } catch (Exception e) {
            log.error("Error al actualizar un producto: {}", e.getMessage());
        }
        return null;
    }


    @Override
    public void deleteProduct(Integer id) {
        productDAO.deleteById(id);
    }

    @Override
    public void deleteProductByName(String nombre) {
        Product product = productDAO.findByNombre(nombre);
        if (product != null) {
            productDAO.delete(product);
        } else {
            log.error("Producto no encontrado por nombre: " + nombre);
        }
    }

    @Override
    public Product getProductByNombre(String nombre) {
        return productDAO.findByNombre(nombre);
    }
}
