package com.api.gestion.pojoEntity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import java.io.Serializable;

@NamedQuery(name = "Product.findByNombre", query = "SELECT p FROM Product p WHERE p.nombre = :nombre")


@Data
@Entity
@DynamicUpdate
@DynamicInsert
@Table(name = "products")

public class Product implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "precio")
    private double precio;

    @Column(name = "stock")
    private int stock;

    @Column(name = "imagen")
    private String imagen;


    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
    public String getImagen() {
        return imagen;
    }
}
