import Cropper from 'cropperjs';

const cropper = new Cropper('#image');

// Exportación de funciones
export { handleScan, handleSelectArea };